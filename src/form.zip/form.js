'use strict';


window.form = (function() {
  var formContainer = document.querySelector('.overlay-container');
  var formCloseButton = document.querySelector('.review-form-close');


  var form = {
    onClose: null,

    /**
     * @param {Function} cb
     */
    open: function(cb) {
      formContainer.classList.remove('invisible');
      cb();
    },

    close: function() {
      formContainer.classList.add('invisible');

      if (typeof this.onClose === 'function') {
        this.onClose();
      }
    }
  };
  var name = document.querySelector('#review-name');
  var text = document.querySelector('#review-text');
  var nameFields = document.querySelector('.review-fields-name');
  var markFirst = document.querySelector('#review-mark-1');
  var markSecond = document.querySelector('#review-mark-2');
  var formControls = document.querySelector('.review-fields');
  var buttons = document.querySelector('.review-submit');

  function validateOnSubmit() {
    var valid = true;
    if (valid) {
      if (name) {
        alert(name.setAttribute('required'));
        alert(nameFields.style.display = 'none');
      }
      if (markFirst.setAttribute('checked') || markSecond.setAttribute('checked')){
        alert(text.setAttribute('required'));
        alert(formControls.style.display = 'none');
      }
    } else {
      alert(buttons.setAttribute('disabled'));
    }
  }
  onchange = validateOnSubmit();
  
  formCloseButton.onclick = function(evt) {
    evt.preventDefault();
    form.close();
  };


  return form;
})();

